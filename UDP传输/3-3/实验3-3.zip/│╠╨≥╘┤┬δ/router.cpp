#define _WINSOCK_DEPRECATED_NO_WARNINGS
#define _CRT_SECURE_NO_WARNINGS 
#include<iostream>
#include<time.h> 
#include <Winsock2.h>
#include<thread>
#include<vector>
#include<time.h>
#include<mutex>	
#include<iomanip>

#pragma comment(lib, "ws2_32.lib")
using namespace std;
const int packetLen = 2048;
const int messageLen = 2020;
char timeRecord[20] = { 0 };

SOCKET routerSrv;
SOCKADDR_IN  Router;
SOCKADDR_IN Server;
SOCKADDR_IN Client;
int len = sizeof(SOCKADDR);


struct DataInWindow {
	bool ack = false;
	char buffer[packetLen];
	int seq;
	int clock;
};
vector<DataInWindow> window;
int windowLength = 10;
std::mutex mtx;

int miss = 200;
int delay = 500;
bool WhetherMiss(int num)
{
	if (num % 100 + 1 > (1-miss) * 100)
		return true;
	else
		return false;
}


void getTime()
{
	//��ȡ��ǰϵͳʱ�䣬д�뵽�ַ�����timeRecord��
	time_t t = time(0);
	strftime(timeRecord, sizeof(timeRecord), "%H:%M:%S", localtime(&t));
}
void routerlog(int ctrl, char buffer[packetLen],int delay=0)
{
	//����һ����Ϣ����ӡ���͵���־
	getTime();
	if(ctrl)
		cout << timeRecord << " [send] ";
	else
		cout << timeRecord << " [recv] ";
	int seq = (int)((unsigned char)buffer[12] << 24) + (int)((unsigned char)buffer[13] << 16) + (int)((unsigned char)buffer[14] << 8) + (int)(unsigned char)buffer[15];
	int ack= (int)((unsigned char)buffer[16] << 24) + (int)((unsigned char)buffer[17] << 16) + (int)((unsigned char)buffer[18] << 8) + (int)(unsigned char)buffer[19];
	cout << "  Seq: " << setw(5) << setiosflags(ios::left) << seq << "Ack: " << setw(5) << setiosflags(ios::left) << ack;
	/*int ACKtmp = (buffer[24] & 0xF0) ? 1 : 0;
	int syntmp = (buffer[24] & 0xF) ? 1 : 0;
	int fintmp = (buffer[25] & 0xF0) ? 1 : 0;
	int sttmp = (buffer[25] & 0xC) ? 1 : 0;
	int ovtmp = (buffer[25] & 0x3) ? 1 : 0;
	cout << "ACK: " << ACKtmp << " SYN: " << syntmp << " FIN: " << fintmp << " ST: " << sttmp << " OV: " << ovtmp;*/
	cout << "\tsendWin:" << window.size();
	if (delay != 0)
	{
		cout << "\tdelay:" << delay;
	}
	cout << endl;
}
void sendToServer()
{
	int sendnum = 0;
	int last = clock();
	int actulDelay = 0;
	while (true)
	{
		if (clock() - last > actulDelay)
		{
			mtx.lock();
			if (window.size() != 0)
			{
				//׼������
				if ((actulDelay == 0) && (sendnum == 1000))
				{
					actulDelay = delay;
					sendnum = 0;
				}
				if ((actulDelay == delay) && (sendnum == 5))
				{
					actulDelay = 0;
					sendnum = 0;
				}
				sendto(routerSrv, window[0].buffer, sizeof(window[0].buffer), 0, (SOCKADDR*)&Server, len);
				routerlog(1, window[0].buffer,actulDelay);
				window.erase(window.begin());
				last = clock();
				sendnum++;
			}
			mtx.unlock();
		}
	}
}
int main()
{
	WORD wVersionRequested;
	WSADATA IpWSAData;
	
	string routerIp = "127.0.0.3";
	string serverIp = "127.0.0.1";
	string clientIp = "127.0.0.2";
	USHORT routerPort = 4444;
	USHORT serverPort = 8888;
	USHORT clientPort = 1111;
	wVersionRequested = MAKEWORD(1, 1);
	int error = WSAStartup(wVersionRequested, &IpWSAData);
	if (error != 0)
	{
		cout << "��ʼ������" << endl;
		exit(0);
	}
	routerSrv = socket(AF_INET, SOCK_DGRAM, 0);
	Router.sin_addr.s_addr = inet_addr(routerIp.c_str());
	Router.sin_family = AF_INET;
	Router.sin_port = htons(routerPort);

	bind(routerSrv, (SOCKADDR*)&Router, sizeof(SOCKADDR));

	Server.sin_addr.s_addr = inet_addr(serverIp.c_str());
	Server.sin_family = AF_INET;
	Server.sin_port = htons(serverPort);
	

	Client.sin_addr.s_addr = inet_addr(clientIp.c_str());
	Client.sin_family = AF_INET;
	Client.sin_port = htons(clientPort);
	char buffer[packetLen];

	int num = -1;
	std::thread t1(sendToServer);
	while (1)
	{
		recvfrom(routerSrv, buffer, sizeof(buffer), 0, (SOCKADDR*)&Client, &len);
		num++;
		//��������,���ζ�����ֱ�ӵ���û�յ�
		if (num%miss!=miss-1)
		{
			mtx.lock();
			if (window.size() < windowLength)
			{
				DataInWindow message;
				for (int x = 0; x < packetLen; x++)
					message.buffer[x] = buffer[x];
				window.push_back(message);
				routerlog(0, buffer);
			}
			mtx.unlock();
		}
	}

}