1. 启动顺序为router，server和Client（UDP.exe）
2. 测试文件源地址为E：/mycode/testfiles
3. 目标地址为：C：/desktop/NetWork